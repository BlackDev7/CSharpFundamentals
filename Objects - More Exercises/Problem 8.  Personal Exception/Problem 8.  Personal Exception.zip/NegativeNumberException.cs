using System;

namespace Problem_8.Personal_Exception
{
    class NegativeNumberException : Exception
    {
        public NegativeNumberException()
            : base() { }

        public NegativeNumberException(string message)
            : base(message) { }
    }
}